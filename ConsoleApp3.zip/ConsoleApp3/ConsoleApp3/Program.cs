﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<string> planetas = new List<string>();
            planetas.Add("Mercúrio");
            planetas.Add("Vênus");
            planetas.Add("Terra");
            foreach (string planeta in planetas)
            {
                WriteLine(planeta);
            }
            
                WriteLine("Acessando pelo índice");
                WriteLine(planetas[0]);
                WriteLine("Removendo um ítem da lista");
                planetas.RemoveAt(0);
                foreach (string planeta in planetas)
                {
                    WriteLine(planeta);
                }
            planetas.Add("Mercúrio");
            planetas.Add("Vênus");
            WriteLine($"Número de elementos da lista: {planetas.Count}");
            bool temMercúrio = planetas.Contains("Mercúrio");
            if (temMercúrio == true)
            {
                WriteLine("Sua lista tem Mercúrio!");
            }
            else
            {
                WriteLine("Sem Mercúrio!");
            }
            WriteLine("Digite um nome de planetas:");
            string planetaDigitado = ReadLine();
            int indiceMercúrio = planetas.IndexOf("Vênus");
            if (indiceMercúrio < 0);
            {


                WriteLine(Este planeta digitado não está na sua lista)
            else


                {
                    WriteLine($"O índice {planetaDigitado} é: {indiceMercúrio}");
                    WriteLine(planetas[índiceMercúrio]);

                List<string> nomes = new List<string>();
                for (int i = 0; i < 5; i++)                  
                {    
                    WriteLine("Digite um nome");
                    string nome = ReadLine();
                    nomes.Add(nome);      
                                             
                }
            foreach (string nome2 in nomes)
            {
                WriteLine(nome2);
            }
            ReadKey();
        }        
    }
}